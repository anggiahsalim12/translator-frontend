# Frontend untuk GitHub Pages

1) Upload semua isi folder ini ke repository GitHub **(root)**.
2) Aktifkan GitHub Pages: Settings → Pages → Deploy from a branch → Branch: `main`, Folder: `/ (root)` → Save.
3) Setelah backend aktif, edit `index.html` dan ganti:
   const API_PROXY_URL = "https://YOUR-BACKEND-URL/api/correct";
   → isikan URL backend milikmu (contoh: https://translator-backend.onrender.com/api/correct).
